# vim-cmake-syntax
Vim syntax highlighting rules for modern CMake.

The vim syntax rules shipped with vim are out-of-date. These ones are less so.

# Installation

With Pathogen

    cd ~/.vim/bundle
    git clone git://github.com/nickhutchinson/vim-cmake-syntax.git

 
With Vundle

    " .vimrc
    Plugin 'nickhutchinson/vim-make-syntax'

