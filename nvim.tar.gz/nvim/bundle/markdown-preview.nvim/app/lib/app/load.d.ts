export default function load(scriptPath: any): any;
